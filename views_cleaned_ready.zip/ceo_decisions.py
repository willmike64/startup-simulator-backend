import streamlit as st

def render_decision_ui():
    st.subheader("💼 CEO Decisions")
    st.write("Strategic pivots, investments, AI advisors")

    with st.expander("🛠 Debug Session State", expanded=False):
        st.json(dict(st.session_state))