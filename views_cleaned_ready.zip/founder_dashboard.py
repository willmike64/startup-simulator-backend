import streamlit as st

def render_investor_ui():
    st.title("📈 Founder Dashboard")
    st.write("This will show startup growth, traction, and KPIs.")

    with st.expander("🛠 Debug Session State", expanded=False):
        st.json(dict(st.session_state))