import streamlit as st

def render_ceo_ui():
    st.title("🧠 CEO Dashboard")
    st.write("Decision-making panel, OKRs, goals, etc.")

    with st.expander("🛠 Debug Session State", expanded=False):
        st.json(dict(st.session_state))