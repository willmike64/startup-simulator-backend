# Stub for company generator
