# Stub for company selection UI
