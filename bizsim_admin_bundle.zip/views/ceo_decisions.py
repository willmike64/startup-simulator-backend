# Stub for CEO decisions UI
