# Stub for staffing UI
