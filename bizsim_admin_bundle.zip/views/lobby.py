# Stub for lobby UI
