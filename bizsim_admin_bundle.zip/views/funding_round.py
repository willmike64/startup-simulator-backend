# Stub for funding UI
