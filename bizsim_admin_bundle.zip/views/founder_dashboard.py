# Stub for investor view UI
