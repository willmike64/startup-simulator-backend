# Stub for onboarding UI
