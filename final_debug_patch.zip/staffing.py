import streamlit as st

def render_staffing_ui():
    st.header("👩‍💼 Team Building")
    st.write("Hire/fill roles, assess team composition")

    with st.expander("🛠 Debug Session State", expanded=False):
        st.json(dict(st.session_state))