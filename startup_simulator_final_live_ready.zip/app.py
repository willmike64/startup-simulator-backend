import streamlit as st
from utils.session import init_session_state
from views import (
    company_list,
    ceo_dashboard,
    ceo_decisions,
    funding_round,
    founder_dashboard as investor_view,
    generate_companies as company_generator,
    lobby,
    onboarding,
    staffing
)
from components import stock_ticker_banner as news_banner

init_session_state()

def navigate(page):
    st.session_state.page = page
    st.rerun()

def app():
    st.set_page_config(page_title="Startup Simulator", layout="wide")

    with st.sidebar:
        st.title("🚀 Startup Simulator")
        st.write("🧭 Page:", st.session_state.page)
        st.write("🎮 Mode:", st.session_state.mode)
        st.write("🎭 Role:", st.session_state.role)
        st.write("🏢 Company ID:", st.session_state.company_id)
        st.write("💰 Funding Done:", st.session_state.funding_complete)

    if st.session_state.page == "intro":
        st.title("💼 Startup Simulation")
        st.markdown("Welcome to the Startup Business Simulation.")
        if st.button("Login / Start"):
            st.session_state.logged_in = True
            navigate("lobby")

    elif st.session_state.page == "lobby":
        lobby.render_lobby(navigate)

    elif st.session_state.page == "onboarding":
        onboarding.render_onboarding(navigate)

    elif st.session_state.page == "funding_round":
        funding_round.render_funding_ui(navigate)

    elif st.session_state.page == "single_player":
        if not st.session_state.funding_complete:
            navigate("funding_round")
        elif st.session_state.role == "CEO":
            company_list.show_company_selection()
            ceo_dashboard.render_ceo_ui()
            ceo_decisions.render_decision_ui()
            staffing.render_staffing_ui()
            news_banner.render_news()
        elif st.session_state.role == "Investor":
            investor_view.render_investor_ui()
            news_banner.render_news()

    elif st.session_state.page == "multiplayer":
        if st.session_state.role == "CEO":
            company_list.show_company_selection()
            ceo_dashboard.render_ceo_ui()
            funding_round.render_funding_ui(navigate)
            ceo_decisions.render_decision_ui()
            staffing.render_staffing_ui()
            news_banner.render_news()
        elif st.session_state.role == "Investor":
            investor_view.render_investor_ui()
            news_banner.render_news()

    else:
        st.error("Unknown page state. Resetting...")
        navigate("intro")

    with st.expander("🛠 Debug Session State"):
        st.json(dict(st.session_state))